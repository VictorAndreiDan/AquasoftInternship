import Tokens from './Tokens';

function App() {

  return (
    <div className="App">
      <Tokens />
    </div>
  );
}

export default App;
