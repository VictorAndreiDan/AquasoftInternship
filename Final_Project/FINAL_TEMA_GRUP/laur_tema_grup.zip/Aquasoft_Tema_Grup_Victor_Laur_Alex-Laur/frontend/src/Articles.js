import { useState, useEffect } from 'react';
import Table from 'react-bootstrap/Table';
import React from 'react';
import axios from 'axios';
import './App.css'

function Articles() {
  const [articles, setArticles] = useState([]);

   useEffect(() => {
    axios.get('http://localhost:5000/articles/').then(res => {

      setArticles(res.data);
    });
  }, []);

  return (
    <div className='App'>
      <Table variant='dark'>
        <thead>
          <tr>
            <th>Article_no</th>
            <th>Article_body</th>
            <th>Article_category</th>
            <th>Article_tokens</th>
          </tr>
        </thead>
        <tbody>
          {articles.map((article) => {
            return (
              <tr key={article._id}>
                <th>{article.Article_no}</th>
                <th>{article.Article_body}</th>
                <th>{article.Article_category}</th>
                <th>{article.Article_tokens}</th>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
}

export default Articles