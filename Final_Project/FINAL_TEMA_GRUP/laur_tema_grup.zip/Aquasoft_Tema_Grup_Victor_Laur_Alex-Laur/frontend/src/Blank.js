const Blank = () => {
    return <div>This is Blank page</div>;
};

export default Blank;