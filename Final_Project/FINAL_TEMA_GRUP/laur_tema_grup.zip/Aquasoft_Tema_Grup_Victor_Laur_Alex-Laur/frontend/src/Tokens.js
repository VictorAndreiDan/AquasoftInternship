import React from 'react';

function Tokens() {
  return (
    <div className='home' style={{paddingLeft: '250px'}}>
      <h1>Tokens</h1>
    </div>
  );
}

export default Tokens;