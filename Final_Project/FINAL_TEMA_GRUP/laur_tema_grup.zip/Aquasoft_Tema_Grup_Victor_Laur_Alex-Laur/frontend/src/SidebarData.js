export const SidebarData = [
  {
    title: 'Articles',
    path: '/articles',
    cName: 'nav-text'
  },
  {
    title: 'Tokens',
    path: '/tokens',
    cName: 'nav-text'
  },
];